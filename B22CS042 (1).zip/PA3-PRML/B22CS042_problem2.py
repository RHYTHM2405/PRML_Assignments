import numpy as np
from sklearn.datasets import fetch_lfw_people
from sklearn.model_selection import train_test_split
from sklearn.decomposition import PCA
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, classification_report
import matplotlib.pyplot as plt

lfw_people = fetch_lfw_people(min_faces_per_person=70, resize=0.4)
# Load the dataset
def load_dataset():
    lfw_people = fetch_lfw_people(min_faces_per_person=70, resize=0.4)
    return lfw_people

# Split the dataset
def split_dataset(X, y):
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    return X_train, X_test, y_train, y_test

# Perform PCA
def perform_pca(X_train, n_components=150):
    pca = PCA(n_components=n_components, svd_solver='randomized', whiten=True).fit(X_train)
    return pca

# Apply PCA transformation
def apply_pca_transform(pca, X_train, X_test):
    X_train_pca = pca.transform(X_train)
    X_test_pca = pca.transform(X_test)
    return X_train_pca, X_test_pca

# Train SVM classifier
def train_svm_classifier(X_train_pca, y_train):
    svm_classifier = SVC(kernel='rbf', class_weight='balanced')
    svm_classifier.fit(X_train_pca, y_train)
    return svm_classifier

# Make predictions
def make_predictions(svm_classifier, X_test_pca):
    y_pred = svm_classifier.predict(X_test_pca)
    return y_pred

# Calculate accuracy
def calculate_accuracy(y_test, y_pred):
    accuracy = accuracy_score(y_test, y_pred)
    return accuracy

# Visualize Eigenfaces
def visualize_eigenfaces(pca, num_faces=10):
    eigenfaces = pca.components_.reshape((pca.n_components_, lfw_people.images.shape[1], lfw_people.images.shape[2]))
    plt.figure(figsize=(8, 6))
    for i in range(num_faces):
        plt.subplot(2, 5, i + 1)
        plt.imshow(eigenfaces[i], cmap='gray')
        plt.title(f"Eigenface {i+1}")
    plt.show()

# Report observations on model performance
def report_performance(y_test, y_pred):
    report = classification_report(y_test, y_pred)
    print(report)

# Experiment with different values of n_components
def experiment_with_n_components(X_train, X_test, y_train, y_test):
    n_samples, n_features = X_train.shape
    max_components = min(n_samples, n_features)
    n_components_values = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 125, 150, 175, 200, 225, max_components]
    accuracies = []

    for n_components in n_components_values:
        pca = perform_pca(X_train, n_components)
        X_train_pca, X_test_pca = apply_pca_transform(pca, X_train, X_test)
        svm_classifier = train_svm_classifier(X_train_pca, y_train)
        y_pred = make_predictions(svm_classifier, X_test_pca)
        accuracy = calculate_accuracy(y_test, y_pred)
        accuracies.append(accuracy * 100)

    return n_components_values, accuracies


# Main function
def main():
    lfw_people = load_dataset()
    X_train, X_test, y_train, y_test = split_dataset(lfw_people.data, lfw_people.target)
    pca = perform_pca(X_train)
    X_train_pca, X_test_pca = apply_pca_transform(pca, X_train, X_test)
    svm_classifier = train_svm_classifier(X_train_pca, y_train)
    y_pred = make_predictions(svm_classifier, X_test_pca)
    report_performance(y_test, y_pred)
    accuracy = calculate_accuracy(y_test, y_pred)
    print("Accuracy:", accuracy)
    
    visualize_eigenfaces(pca)
    
    n_components_values, accuracies = experiment_with_n_components(X_train, X_test, y_train, y_test)
    plt.figure(figsize=(10, 6))
    plt.plot(n_components_values, accuracies, marker='o')
    plt.title('Impact of n_components on Accuracy')
    plt.xlabel('Number of Components')
    plt.ylabel('Accuracy')
    plt.xticks(np.arange(0, 251, step=25))
    plt.grid(True)
    plt.show()

if __name__ == "__main__":
    main()
