import numpy as np


"""
w0=1
w1=2
w2=3
w3=4
w4=5
"""
weights = np.array([[1, 2, 3, 4, 5]])

sample_size=2400
weights_excluding_first = weights[:, 1:]
train_samples=[]
nsamples=[]
psamples=[]
dot_prod=[]
np.random.seed(42)
train_samples=np.random.randint(-5, 5, size=(sample_size, 4))
bias = np.full((1, sample_size), weights[0,0])
dot_prod=np.dot(weights_excluding_first,train_samples.T)
dot_prod=dot_prod+bias

last_column=np.random.randint(0, 1, size=(sample_size, 1))


for i in range(sample_size):
  if(dot_prod[0,i])>=0:
    last_column[i,0]=1

  else:
    last_column[i]=0


final_train_data= np.concatenate((train_samples, last_column), axis=1)

with open('data.txt', 'w') as file:
    for row in final_train_data:
        row_str = ','.join(map(str, row))
        file.write(row_str + '\n')

np.random.shuffle(final_train_data)

# Determine the split index for 80% training and 20% testing
split_index = int(0.8 * len(final_train_data))

# Split the data into training and testing sets
train_data = final_train_data[:split_index]
test_data = final_train_data[split_index:, :-1] 
num_input_vectors = train_data.shape[0]

# Write training data to train.txt
with open('train.txt', 'w') as file:
    # Write the number of input vectors as the first line
    file.write(str(num_input_vectors) + '\n')
    
    # Write each input vector to the file
    for row in train_data:
        row_str = ','.join(map(str, row))
        file.write(row_str + '\n')

num_input_vectors1 = test_data.shape[0]
# Save testing data to test.txt
with open('test.txt', 'w') as file:

    file.write(str(num_input_vectors1) + '\n')
    
    # Write each input vector to the file
    for row in test_data:
        row_str = ','.join(map(str, row))
        file.write(row_str + '\n')

