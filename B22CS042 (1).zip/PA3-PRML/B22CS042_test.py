import numpy as np
import argparse

def main(test_file):
    # Load testing data (without labels)
    test_data = np.loadtxt(test_file, delimiter=',', skiprows=1)

    # Load initial weights
    initial_weights = np.array([1, 2, 3, 4, 5])

    # Load trained weights
    trained_weights = np.loadtxt('B22CS042_weight.txt')
    num_data_points = test_data.shape[0]

    # Normalize the testing data
    X_test = test_data / np.linalg.norm(test_data, axis=1, keepdims=True)
    y_pred = np.zeros(num_data_points, dtype=int)

    # Compute predictions using new weights
    for i in range(num_data_points):
        prediction = np.dot(trained_weights[1:], X_test[i]) + trained_weights[0]
        y_pred[i] = 1 if prediction >= 0 else 0

    # Print predictions in CSV format
    print(",".join(map(str, y_pred)))

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("test_file", help="Path to the test file (test.txt)")
    args = parser.parse_args()

    main(args.test_file)
