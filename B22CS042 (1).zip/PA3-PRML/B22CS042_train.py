import numpy as np
import argparse

def main(train_file):
    np.random.seed(42)
    train_data = np.loadtxt(train_file, delimiter=',', skiprows=1)

    # Extract features (X_train) and labels (y_train) from train_data
    X_train = train_data[:, :-1]
    y_train = train_data[:, -1]
    X_train_normalized = X_train / np.linalg.norm(X_train, axis=1, keepdims=True)

    # Assuming X_train_normalized and y_train are defined
    epochs = 2

    # Initialize weights as float values
    weight_new = np.random.uniform(0, 5, size=(1, 5))

    # Set the learning rate
    learning_rate = 0.01

    for epoch in range(epochs):
        for i in range(len(X_train_normalized)):  # Loop over the number of samples

            # Compute prediction
            prediction = 1 if np.dot(weight_new[:, 1:], X_train_normalized[i, :]) >= 0 else 0

            # Update weights if prediction is incorrect
            if prediction != y_train[i]:
                if prediction == 0:
                    weight_new[0, 1:] -= learning_rate * X_train_normalized[i]  # Apply learning rate to update
                else:
                    weight_new[0, 1:] += learning_rate * X_train_normalized[i]  # Apply learning rate to update

    # Save the trained weights to weight.txt
    np.savetxt('weight.txt', weight_new)

    print("Training Over and Weights are saved")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("train_file", help="Path to the training file (train.txt)")
    args = parser.parse_args()

    main(args.train_file)
