README.txt

Perceptron - Linear Classification

In this problem, you will implement the Perceptron algorithm to solve a linear classification problem. Below are the details and tasks associated with this problem:

Dataset Description:
The training input file consists of vectors with their corresponding labels.
Each line in the training file represents a 4-dimensional input vector followed by its label (0 or 1).
The first line of the file indicates the total number of input vectors.
The testing input file is similar to the training file but does not contain labels.
Tasks:
Task-0: Generating Synthetic Dataset:

Initialize a linear function: f(x) = w0 + w1x1 + w2x2 + w3x3 + w4x4.
Randomly choose w0, w1, w2, w3, and w4.
Evaluate f(x). If the result is greater than or equal to zero, label it as a positive example; otherwise, label it as a negative example.
Deliverable: data.txt
Task-1: Training Code for Perceptron:

Write training code for the Perceptron learning algorithm.
Normalize the data during both training and testing.
Deliverable: train.py
Task-2: Testing and Evaluation Code:

Write testing and evaluation code.
Report accuracy.
Deliverable: test.py
Task-3: Reporting Results:

Report results with training using 20%, 50%, and 70% of synthetic data.
Deliverable: Table in the report comparing results.
Usage:
Execute train.py with the training dataset file as an argument to save the weights.
Execute test.py with the testing dataset file to obtain the labels of each sample in a comma-separated form.